#ifndef _Contexte_h
#define _Contexte_h

#include <stdint.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* Clause SETS */

/* Clause CONCRETE_VARIABLES */


/* Clause CONCRETE_CONSTANTS */
/* Basic constants */
/* TO DO: #define Contexte__ROULIS */
/* TO DO: #define Contexte__LACET */
/* TO DO: #define Contexte__VITESSE */
/* TO DO: #define Contexte__TANGAGE */
/* Array and record constants */




extern void Contexte__INITIALISATION(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* _Contexte_h */
