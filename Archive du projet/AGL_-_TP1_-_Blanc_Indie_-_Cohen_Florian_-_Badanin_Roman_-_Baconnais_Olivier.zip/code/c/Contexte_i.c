/* WARNING if type checker is not performed, translation could contain errors ! */

#include "Contexte.h"

/* Clause CONCRETE_CONSTANTS */
/* Basic constants */

#define Contexte__ROULIS 360
#define Contexte__LACET 360
#define Contexte__VITESSE 3000
#define Contexte__TANGAGE 360
/* Array and record constants */
/* Clause CONCRETE_VARIABLES */

/* Clause INITIALISATION */
void Contexte__INITIALISATION(void)
{
    
    ;
}

